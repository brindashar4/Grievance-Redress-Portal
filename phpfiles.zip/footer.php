<!DOCTYPE html>
<html>
<head>
  <style type="text/css">
.header35{
  float: left;
  width: 100vw;
  height: 100px;
  left-margin:600px;
  text-shadow: 1px 1px red;
  font-family: "Times New Roman", Times, serif;
  font-size: 180%;
  text-align: center;

}
</style>
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
</body>
<footer class="header35">
<hr style="border-width: 2px; border-color: rgb(0,0,0);" />
  © 2018-19 KJSCE, All Rights Reserved. <br>
  Version 1.0
</footer>
</html>