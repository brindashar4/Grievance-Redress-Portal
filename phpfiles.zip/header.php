<!DOCTYPE html>
<html>
<head>
  <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
  <style type="text/css">
.header33{
  float: left;
  width: 100px;
  height: 80px;
  margin:-03px;
  margin-top: 20px;
  margin-bottom: 0px;
}
.header34{
  float: left;
  width: 800px;
  height: 80px;
  left-margin:600px;
  padding-left: 200px;
  margin-top: 20px;
  margin-bottom: 0px;
  text-shadow: 1px 1px red;
  font-family: "Times New Roman", Times, serif;
  font-size: 180%;
  text-align: center;
}
body {
  background-image: url("white.jpg");
}
</style>
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<header align="right">
<div class="container">
      <div class="header33">
        <img src="somaiya.png" alt="logo" height="80" width="300"/>
      </div>
      <div class="header34">
       <p>K. J. Somaiya College of Engineering, Vidyavihar </p>
       <p style = "font-size: 90%;">(Autonomous College Affiliated to University of Mumbai)</p>
      </div>
</div>
<hr style="border-width: 2px; border-color: rgb(0,0,0);" />
</header>
<body>
</body>
</html>